import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';

class AdminGasStationPage extends StatefulWidget {
  const AdminGasStationPage({super.key});

  @override
  State<AdminGasStationPage> createState() => _AdminGasStationPageState();
}

class _AdminGasStationPageState extends State<AdminGasStationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: AppBar(
        title: const Text("Admin Dashboard", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600),),
        centerTitle: true,
        elevation: 2,
        backgroundColor: Colors.blue.shade600,
        shadowColor: Colors.grey.shade300,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tabs
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children:  [
                _DashboardTab(
                    icon: LucideIcons.fuel,
                    label: "Gas Stations",
                    selected: true),
                _DashboardTab(icon: LucideIcons.users, label: "Users"),
                _DashboardTab(icon: LucideIcons.fileText, label: "Orders"),
              ],
            ),
            const SizedBox(height: 20),

            const Text(
              "Gas Station Management",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 12),

            // Search + Add Button
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Search gas stations by name or location",
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.add),
                  label: const Text("Add Gas Station"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade600,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Table Header
            const _TableHeader(),

            const SizedBox(height: 10),

            // Station List
            Expanded(
              child: ListView(
                children: const [
                  _StationRow(
                    name: "City Center Gas",
                    location: "123 Market St\nSan Francisco, CA",
                    inventory:
                        "Petrol: 5000 gal\nDiesel: 3000 gal\nGasoline: 4000 gal",
                    manager: "John Smith\njohn@citycentergas.com",
                  ),
                  _StationRow(
                    name: "Riverside Fuel",
                    location: "456 Riverside Dr\nLos Angeles, CA",
                    inventory:
                        "Petrol: 4500 gal\nDiesel: 5000 gal\nGasoline: 3200 gal",
                    manager: "Sarah Johnson\nsarah@riversidefuel.com",
                  ),
                  _StationRow(
                    name: "Golden Gate Petrol",
                    location: "789 Golden Gate Ave\nSan Francisco, CA",
                    inventory:
                        "Petrol: 6000 gal\nDiesel: 4500 gal\nGasoline: 5200 gal",
                    manager: "Michael Wilson\nmichael@ggpetrol.com",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------- Custom Widgets -------------------------

class _DashboardTab extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool selected;

  const _DashboardTab({
    required this.icon,
    required this.label,
    this.selected = false,
  });

  @override
  State<_DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<_DashboardTab> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(widget.icon, color: widget.selected ? Colors.blue : Colors.grey),
        Text(
          widget.label,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            color: widget.selected ? Colors.blue : Colors.grey,
          ),
        ),
        if (widget.selected)
          Container(
            margin: const EdgeInsets.only(top: 5),
            height: 3,
            width: 60,
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
      ],
    );
  }
}

class _TableHeader extends StatelessWidget {
  const _TableHeader();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        Expanded(flex: 2, child: Text("Name", style: _headerStyle)),
        Expanded(flex: 2, child: Text("Location", style: _headerStyle)),
        Expanded(flex: 3, child: Text("Inventory", style: _headerStyle)),
        Expanded(flex: 2, child: Text("Manager", style: _headerStyle)),
        SizedBox(width: 50), // For actions
      ],
    );
  }
}

class _StationRow extends StatelessWidget {
  final String name;
  final String location;
  final String inventory;
  final String manager;

  const _StationRow({
    required this.name,
    required this.location,
    required this.inventory,
    required this.manager,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      color: Colors.white,
      shadowColor: Colors.grey.shade300,
      
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: const BorderSide(color: Colors.grey, width: 1),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
                flex: 2,
                child: Text(name,
                    style: const TextStyle(fontWeight: FontWeight.w600))),
            Expanded(flex: 2, child: Text(location)),
            Expanded(flex: 3, child: Text(inventory)),
            Expanded(flex: 2, child: Text(manager)),
            Column(
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.deepPurple),
                  onPressed: () {},
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {},
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

const _headerStyle = TextStyle(fontWeight: FontWeight.bold, fontSize: 14);
